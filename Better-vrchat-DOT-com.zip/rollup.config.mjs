export default {
    input: 'better_vrc_dot_com/build/content/better_vrc_dot_com.js',
    output: {
        file: 'better_vrc_dot_com/dist/index.js',
        format: 'iife'
    }
};